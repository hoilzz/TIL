// action을 이해하기 위해 천천히 가르쳐서 reducer 작성해보자.

import {SELECT_OBJ} from '../actions';

export const initialState = {
    answerList: [
        {
            answer_id: 5,
            answerType: 'objective',
            title: '가장 좋아하는 음식은?',
            options: [
                {
                    id: 1,
                    title: '와퍼세트'
                },
                {
                    id: 2,
                    title: '네네치킨'
                },
                {
                    id: 3,
                    title: '타코'
                },
                {
                    id: 4,
                    title: '초밥'
                }
            ]
        },
        {
            answer_id: 6,
            answerType: 'objective',
            title: '가장 싫어하는 음식은?',
            options: [
                {
                    id: 12,
                    title: '미역국'
                },
                {
                    id: 13,
                    title: '모니터'
                },
                {
                    id: 14,
                    title: '키보드'
                },
                {
                    id: 15,
                    title: '마우스'
                }
            ]
        }
    ],
    selection: -1
};

export function selectObjective(state = initialState, action){
    console.log(state.selection);
    switch (action.type){
        case SELECT_OBJ:
            return Object.assign({}, state, {
                selection: action.selection
            })
        default:
            return state;
    }
}