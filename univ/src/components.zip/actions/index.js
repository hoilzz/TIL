export const SELECT_OBJ = 'SELECT_OBJ';

export function select_obj(selection){
    return {
        type: SELECT_OBJ,
        selection
    }
}