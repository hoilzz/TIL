import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {select_obj} from '../actions';
import {connect} from 'react-redux';
import ObjectiveEx from './ObjectiveEx';

class ObjectiveItem extends Component {
    constructor(props){
        super(props);
    }

    objectiveToComponent = () => {
        return (
            this.props.objectiveInfo.map( (item, index) => {
                return (
                    <form key={item.answer_id}>
                        <p>{item.title}</p>
                        {this.exampleToComponent(item.options)}
                    </form>
                );
            } )
        )
    }

    exampleToComponent = (options) => {
        return(
            options.map( (option, index) => {
                return (
                        <ObjectiveEx    
                                key = {option.id}
                                onUpdateSelection = {this.props.updateSelection}
                                content = {option.title}
                                exId = {option.id}
                                exIdx = {index}
                             />
                        );
            })
        );
    }

    render() {
        return (
           <div>
               {this.objectiveToComponent()}
           </div>
       );
    }
}

ObjectiveItem.propTypes = {

};

export default ObjectiveItem;