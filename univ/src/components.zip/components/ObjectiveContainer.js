import {connect} from 'react-redux';
import {select_obj} from '../actions';
import ObjectiveItem from './ObjectiveItem';

const mapDispatchToProps = (dispatch) => {
    return {
        updateSelection: (selection) => {
            dispatch(select_obj(selection));
        }
    }
}

const mapStateToProps = (state) => {
    return {
        objectiveInfo: state.answerList
    }
}

const ObjectiveContainer = connect(mapStateToProps, mapDispatchToProps)(ObjectiveItem);

export default ObjectiveContainer;