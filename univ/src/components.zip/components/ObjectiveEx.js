import React, { Component } from 'react';
import PropTypes from 'prop-types';

class ObjectiveEx extends Component {
    constructor(props){
        super(props);
    }

    onClick = (event, idx) => {
        this.props.onUpdateSelection(idx);
    }

    makeId = (id) => {
        return "ex"+id
    }

    render() {
        return (
            <div>
                <input 
                    onClick={event => this.onClick(event,this.props.exIdx)} 
                    name={"objective"}
                    id={this.makeId(this.props.exId)} 
                    type="radio"
                    />
                <label htmlFor={this.makeId(this.props.exId)}>{this.props.content}</label>
            </div>
        );
    }
}

ObjectiveEx.propTypes = {

};

export default ObjectiveEx;